from django.shortcuts import render,redirect
from .models import Company
from .forms import CompanyForm
from django.contrib.auth.models import User
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger

def empview(request):
    form=CompanyForm()
    template_name='Company/companyform.html'
    context={'form':form}

    if request.method=="POST":
        form=CompanyForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('show.urls')
    return render(request,template_name,context)

def showemp(request):
    template_name='Company/showcompany.html' 
    data=Company.objects.all()
   
    paginator = Paginator(data, 5)
    try:
        if request.GET.get('page'):
            data = paginator.page(request.GET.get('page'))
        else:
            data=paginator.page(1)

    except EmptyPage:
        data = paginator.page(paginator.num_pages)

    template_name='Company/showcompany.html' 
    context={'data':data}
    return render(request,template_name,context)   


def updateview(request,eid):
    obj=Company.objects.get(eid=eid)
    form=CompanyForm(instance=obj)
    template_name='Company/companyform.html'
    context={'form':form}

    if request.method=="POST":
        form=CompanyForm(request.POST,instance=obj)
        if form.is_valid():
            form.save()
            return redirect('showemp.urls')
    return render(request,template_name,context)     


def deleteview(request,eid):
    obj=Company.objects.get(eid=eid)
    template_name='Company/confirmation.html'
    context={'obj':obj}

    if request.method=="POST":
        obj.delete()
        return redirect('show.urls')
    return render(request,template_name,context)







# Create your views here.
