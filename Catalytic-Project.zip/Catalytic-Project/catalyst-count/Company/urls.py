from django.urls import path
from .import views

urlpatterns=[
    path('emp/',views.empview,name='emp.urls'),
    path('se/',views.showemp,name='show.urls'),
    path('ue/<int:eid>/',views.updateview,name='update.urls'),
    path('de/<int:eid>/',views.deleteview,name='delete.urls')
]